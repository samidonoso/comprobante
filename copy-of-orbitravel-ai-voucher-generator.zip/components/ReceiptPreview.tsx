
import React from 'react';
import { ReceiptData } from '../types';
import { formatCurrency, formatDate } from '../utils/formatters';
import { GlobeAltIcon, PrinterIcon, PlusIcon, CheckCircleIcon, PhoneIcon, EnvelopeIcon } from './icons/Icons';

interface ReceiptPreviewProps {
    data: ReceiptData;
    onGenerateNew: () => void;
}

const InfoItem: React.FC<{ label: string; value: React.ReactNode }> = ({ label, value }) => (
    <div className="flex justify-between items-start py-3 px-4 bg-slate-50/70 rounded-lg border border-slate-200/50">
        <span className="text-sm font-medium text-slate-500">{label}</span>
        <span className="text-sm font-semibold text-slate-800 text-right">{value}</span>
    </div>
);

const ReceiptPreview: React.FC<ReceiptPreviewProps> = ({ data, onGenerateNew }) => {
    const balance = data.totalTripValue - data.amountPaid;

    const handlePrint = () => {
        window.print();
    };

    return (
        <div id="receipt-preview" className="bg-white rounded-2xl shadow-2xl border border-slate-200/50 overflow-hidden transition-all duration-300 ease-in-out animate-fade-in">
            {/* Header */}
            <header className="bg-gradient-to-br from-indigo-500 to-purple-600 text-white p-8">
                <div className="flex justify-between items-start flex-wrap gap-4">
                    <div className="flex items-center gap-4">
                        <div className="p-2 bg-white/20 rounded-lg">
                           <GlobeAltIcon className="w-8 h-8 text-white" />
                        </div>
                        <div>
                            <h2 className="text-2xl font-bold">Orbitravel</h2>
                            <p className="text-sm opacity-90">Agencia de Viajes Profesional</p>
                        </div>
                    </div>
                    <div className="text-right">
                        <h1 className="text-3xl font-extrabold tracking-tight">BOLETA DE ABONO</h1>
                        <p className="text-xs opacity-90 mt-1"><strong>Fecha:</strong> {formatDate(data.receiptDate)}</p>
                        <p className="text-xs opacity-90"><strong>N°:</strong> {data.receiptNumber}</p>
                    </div>
                </div>
            </header>

            {/* Content */}
            <main className="p-8 space-y-8">
                {/* Client Info */}
                <section>
                    <h3 className="text-lg font-bold text-indigo-600 mb-4 border-b-2 border-indigo-100 pb-2">Datos del Cliente</h3>
                    <div className="space-y-2">
                        <InfoItem label="Nombre" value={data.clientName} />
                        <InfoItem label="Correo" value={data.clientEmail || 'No especificado'} />
                        <InfoItem label="Dirección" value={data.clientAddress || 'No especificado'} />
                    </div>
                </section>

                {/* Trip & Financials */}
                <section>
                    <h3 className="text-lg font-bold text-indigo-600 mb-4 border-b-2 border-indigo-100 pb-2">Detalles del Viaje y Pago</h3>
                     <div className="overflow-x-auto">
                        <table className="w-full text-sm">
                            <thead className="border-b-2 border-slate-200">
                                <tr>
                                    <th className="py-2 px-3 text-left font-semibold text-slate-600">Descripción</th>
                                    <th className="py-2 px-3 text-left font-semibold text-slate-600">Servicios Incluidos</th>
                                    <th className="py-2 px-3 text-right font-semibold text-slate-600">Valor Total</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr className="border-b border-slate-100">
                                    <td className="py-3 px-3 align-top">
                                        <p className="font-bold text-slate-800">{data.tripDescription}</p>
                                        <p className="text-slate-500">{data.tripMonth}</p>
                                        <p className="text-slate-500">{data.paxCount}</p>
                                    </td>
                                    <td className="py-3 px-3 align-top text-slate-600">{data.tripInclusions}</td>
                                    <td className="py-3 px-3 align-top text-right font-bold text-lg text-slate-800">{formatCurrency(data.totalTripValue)}</td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
                    <div className="mt-4 grid md:grid-cols-2 gap-4">
                        <div className="bg-green-50 border-l-4 border-green-400 p-4 rounded-r-lg">
                            <p className="text-sm font-medium text-green-700">Abono Realizado</p>
                            <p className="text-2xl font-bold text-green-600">{formatCurrency(data.amountPaid)}</p>
                        </div>
                        <div className="bg-orange-50 border-l-4 border-orange-400 p-4 rounded-r-lg">
                            <p className="text-sm font-medium text-orange-700">Saldo Pendiente</p>
                            <p className="text-2xl font-bold text-orange-600">{formatCurrency(balance)}</p>
                        </div>
                    </div>
                </section>

                {/* Package Details */}
                {data.generalDetails && (
                <section>
                    <h3 className="text-lg font-bold text-indigo-600 mb-4 border-b-2 border-indigo-100 pb-2">Detalles del Paquete</h3>
                    <ul className="space-y-2">
                        {data.generalDetails.split('\n').filter(d => d.trim() !== '').map((detail, index) => (
                            <li key={index} className="flex items-start gap-3">
                                <CheckCircleIcon className="w-5 h-5 text-green-500 mt-0.5 flex-shrink-0" />
                                <span className="text-sm text-slate-600">{detail}</span>
                            </li>
                        ))}
                    </ul>
                </section>
                )}
                
                 {/* Contact & Footer */}
                <section className="pt-4 space-y-6">
                     <div className="bg-slate-50 p-6 rounded-xl border border-slate-200/80">
                         <h3 className="font-bold text-slate-700 mb-3">Información de Contacto - Orbitravel</h3>
                         <p className="text-sm text-slate-600 mb-4 font-semibold">¡NO DUDES EN CONSULTARNOS!</p>
                         <div className="flex flex-wrap gap-x-6 gap-y-2">
                            <a href="mailto:orbitravelviajes@gmail.com" className="flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-800 font-medium">
                                <EnvelopeIcon className="w-5 h-5"/> orbitravelviajes@gmail.com
                            </a>
                             <a href="tel:+56986809215" className="flex items-center gap-2 text-sm text-indigo-600 hover:text-indigo-800 font-medium">
                                <PhoneIcon className="w-5 h-5"/> +56 9 8680 9215
                            </a>
                         </div>
                     </div>
                     <p className="text-center text-xs text-slate-400 pt-4 border-t border-slate-200">
                        Este es un comprobante de abono generado por Orbitravel. Documento válido para efectos de registro contable.
                     </p>
                </section>
                
                {/* Actions */}
                <div className="pt-4 flex flex-col sm:flex-row gap-4 justify-center no-print">
                    <button onClick={handlePrint} className="flex items-center justify-center gap-2 w-full sm:w-auto px-6 py-3 bg-slate-700 text-white font-semibold rounded-lg shadow-md hover:bg-slate-800 transition-all">
                        <PrinterIcon className="w-5 h-5" /> Imprimir / Guardar PDF
                    </button>
                    <button onClick={onGenerateNew} className="flex items-center justify-center gap-2 w-full sm:w-auto px-6 py-3 bg-indigo-600 text-white font-semibold rounded-lg shadow-md hover:bg-indigo-700 transition-all">
                        <PlusIcon className="w-5 h-5" /> Generar Nuevo
                    </button>
                </div>
            </main>
        </div>
    );
};

export default ReceiptPreview;
