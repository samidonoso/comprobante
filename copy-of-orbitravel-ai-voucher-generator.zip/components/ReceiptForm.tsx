
import React, { useState, useCallback } from 'react';
import { ReceiptData, GeminiSuggestion } from '../types';
import FormSection from './FormSection';
import Input from './common/Input';
import Textarea from './common/Textarea';
import Button from './common/Button';
import { UserIcon, BriefcaseIcon, CurrencyDollarIcon, DocumentTextIcon, SparklesIcon, ArrowPathIcon } from './icons/Icons';

interface ReceiptFormProps {
    onGenerate: (data: Omit<ReceiptData, 'receiptNumber' | 'receiptDate'>) => void;
    onSuggest: (tripDescription: string, tripMonth: string) => Promise<GeminiSuggestion | null>;
    isGenerating: boolean;
}

const initialFormData = {
    clientName: 'NATALIA DE LOURDES LA ROSA IBAÑEZ',
    clientEmail: 'cliente@email.com',
    clientAddress: 'Dirección del cliente',
    tripDescription: 'Viaje grupal Encanto Europeo',
    tripMonth: 'junio 2025',
    paxCount: '1 persona',
    tripInclusions: 'Vuelos, Hotel, Desayuno, Tours',
    totalTripValue: 3840990,
    amountPaid: 400000,
    generalDetails: 'Vuelos ida y vuelta desde Santiago a Barcelona/Roma a Santiago\nHotel\nBolso y equipaje de mano\nDesayuno incluido\nTraslados aeropuerto/hotel\nTraslados entre países\nEntrada a Sagrada Familia\nTours Coliseo Romano\nTours Torre Eiffel\nTours por canales de Amsterdam\nAcompañados de Team Leader\nAsesoría 24 horas',
};

const ReceiptForm: React.FC<ReceiptFormProps> = ({ onGenerate, onSuggest, isGenerating }) => {
    const [formData, setFormData] = useState(initialFormData);
    const [isSuggesting, setIsSuggesting] = useState(false);

    const handleChange = useCallback((e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
        const { id, value, type } = e.target;
        setFormData(prev => ({
            ...prev,
            [id]: type === 'number' ? (value === '' ? '' : parseFloat(value)) : value,
        }));
    }, []);

    const handleSuggest = async () => {
        setIsSuggesting(true);
        const suggestions = await onSuggest(formData.tripDescription, formData.tripMonth);
        if (suggestions) {
            setFormData(prev => ({
                ...prev,
                tripInclusions: suggestions.inclusions,
                generalDetails: suggestions.details.join('\n'),
            }));
        }
        setIsSuggesting(false);
    };

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        onGenerate({ ...formData, totalTripValue: Number(formData.totalTripValue), amountPaid: Number(formData.amountPaid) });
    };
    
    const handleReset = () => {
        if(window.confirm('¿Está seguro de que desea limpiar todo el formulario?')) {
            setFormData(initialFormData);
        }
    };

    return (
        <form onSubmit={handleSubmit} className="space-y-8">
            <h2 className="text-2xl font-bold text-center text-slate-800">Crear Nuevo Comprobante</h2>

            <FormSection title="Datos del Cliente" icon={<UserIcon className="w-6 h-6" />}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input id="clientName" label="Nombre Completo" value={formData.clientName} onChange={handleChange} required />
                    <Input id="clientEmail" label="Correo Electrónico" type="email" value={formData.clientEmail} onChange={handleChange} />
                </div>
                <Input id="clientAddress" label="Dirección" value={formData.clientAddress} onChange={handleChange} />
            </FormSection>

            <FormSection title="Información del Viaje" icon={<BriefcaseIcon className="w-6 h-6" />}>
                <div className="relative">
                    <Input id="tripDescription" label="Descripción del Viaje" value={formData.tripDescription} onChange={handleChange} required />
                    <Button
                        type="button"
                        onClick={handleSuggest}
                        disabled={isSuggesting}
                        className="!absolute right-1 bottom-1 !py-1 !px-2 text-xs"
                        variant="ghost"
                    >
                        {isSuggesting ? <ArrowPathIcon className="w-4 h-4 animate-spin" /> : <SparklesIcon className="w-4 h-4" />}
                        {isSuggesting ? 'Sugiriendo...' : 'Sugerir con IA'}
                    </Button>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input id="tripMonth" label="Mes del Viaje" value={formData.tripMonth} onChange={handleChange} required />
                    <Input id="paxCount" label="Número de Personas" value={formData.paxCount} onChange={handleChange} required />
                </div>
                <Textarea id="tripInclusions" label="Servicios Incluidos (sugeridos por IA)" value={formData.tripInclusions} onChange={handleChange} placeholder="Separar con comas" rows={3} />
            </FormSection>

            <FormSection title="Detalles Financieros" icon={<CurrencyDollarIcon className="w-6 h-6" />}>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <Input id="totalTripValue" label="Valor Total del Viaje ($)" type="number" value={formData.totalTripValue} onChange={handleChange} required min="0" />
                    <Input id="amountPaid" label="Monto Abonado ($)" type="number" value={formData.amountPaid} onChange={handleChange} required min="0" />
                </div>
            </FormSection>
            
            <FormSection title="Detalles del Paquete" icon={<DocumentTextIcon className="w-6 h-6" />}>
                <Textarea id="generalDetails" label="Detalles Adicionales (sugeridos por IA)" value={formData.generalDetails} onChange={handleChange} placeholder="Una línea por cada detalle" rows={8} />
            </FormSection>
            
            <div className="flex flex-col sm:flex-row gap-4 justify-center pt-4">
                <Button type="submit" disabled={isGenerating} className="w-full sm:w-auto">
                    {isGenerating ? <ArrowPathIcon className="w-5 h-5 animate-spin" /> : null}
                    {isGenerating ? 'Generando...' : 'Generar Comprobante'}
                </Button>
                <Button type="button" variant="danger" onClick={handleReset} className="w-full sm:w-auto">
                    Limpiar Formulario
                </Button>
            </div>
        </form>
    );
};

export default ReceiptForm;
