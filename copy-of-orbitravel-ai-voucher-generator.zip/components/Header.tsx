
import React from 'react';
import { GlobeAltIcon } from './icons/Icons';

const Header: React.FC = () => {
    return (
        <header className="py-8 text-center no-print">
            <div className="flex justify-center items-center gap-4">
                 <div className="p-3 bg-gradient-to-br from-indigo-500 to-purple-600 rounded-2xl shadow-lg">
                    <GlobeAltIcon className="w-10 h-10 text-white" />
                 </div>
                <div>
                     <h1 className="text-4xl sm:text-5xl font-extrabold text-slate-800 tracking-tight">
                        Orbitravel
                    </h1>
                    <p className="mt-1 text-lg text-slate-600">Generador de Comprobantes de Abono</p>
                </div>
            </div>
        </header>
    );
};

export default Header;
