
import React from 'react';

interface FormSectionProps {
    title: string;
    icon: React.ReactNode;
    children: React.ReactNode;
}

const FormSection: React.FC<FormSectionProps> = ({ title, icon, children }) => {
    return (
        <fieldset className="space-y-4">
            <legend className="w-full">
                <div className="flex items-center gap-3 pb-3 border-b-2 border-slate-200/80">
                    <div className="text-indigo-600">
                        {icon}
                    </div>
                    <h3 className="text-lg font-bold text-slate-700">{title}</h3>
                </div>
            </legend>
            <div className="space-y-4 pt-2">
                {children}
            </div>
        </fieldset>
    );
};

export default FormSection;
