
import { GoogleGenAI } from "@google/genai";
import { GeminiSuggestion } from '../types';

if (!process.env.API_KEY) {
    throw new Error("API_KEY environment variable is not set.");
}

const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

export async function generateTripDetails(tripDescription: string, tripMonth: string): Promise<GeminiSuggestion | null> {
    const prompt = `
        You are an expert travel agent assistant for a company named "Orbitravel". 
        Your task is to generate a list of typical inclusions and additional package details for a specific trip.
        The response must be in valid JSON format.

        Based on the following trip information:
        - Trip Name: "${tripDescription}"
        - Travel Month: "${tripMonth}"

        Please provide a response as a JSON object with two keys: "inclusions" and "details".
        - "inclusions": A string containing a comma-separated list of 4-5 key services typically included (e.g., "Vuelos, Hotel, Desayuno, Tours").
        - "details": An array of 8-12 strings, where each string is a specific, appealing detail about the package. Be creative and professional.

        Example JSON output:
        {
          "inclusions": "Vuelos, Alojamiento, Traslados, Tours guiados",
          "details": [
            "Vuelo internacional Santiago - Madrid",
            "Hotel céntrico 3-4 estrellas con desayuno buffet",
            "Traslados aeropuerto-hotel-aeropuerto en vehículo privado",
            "Tour panorámico en Madrid con guía local",
            "Billete de tren alta velocidad Madrid - Barcelona",
            "Entrada preferente a la Sagrada Familia",
            "Seguro de asistencia en viaje",
            "Kit de viaje Orbitravel de bienvenida"
          ]
        }
    `;

    try {
        const response = await ai.models.generateContent({
            model: "gemini-2.5-flash-preview-04-17",
            contents: prompt,
            config: {
                responseMimeType: "application/json",
                temperature: 0.7,
            },
        });

        let jsonStr = response.text.trim();
        const fenceRegex = /^```(\w*)?\s*\n?(.*?)\n?\s*```$/s;
        const match = jsonStr.match(fenceRegex);
        if (match && match[2]) {
            jsonStr = match[2].trim();
        }

        const parsedData = JSON.parse(jsonStr) as GeminiSuggestion;
        
        if (parsedData && parsedData.inclusions && Array.isArray(parsedData.details)) {
             return parsedData;
        }
        throw new Error("Parsed JSON does not match expected format.");

    } catch (error) {
        console.error("Error generating trip details from Gemini:", error);
        throw new Error("Failed to parse or retrieve suggestions from AI.");
    }
}
